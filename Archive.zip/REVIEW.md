---
layout: page
title: Ôn tập
---

Đây là bài tập cho các em trong những ngày nghỉ học vì dịch Corona. Xin nhờ quý phụ huynh hướng dẫn cho các em thực hiện.

**Các file cũ.**
* [Ngày 20/02/2020.](review/20200220.html)
* [Ngày 24/02/2020.](review/20200224.html)

**File mới.**
> [Ngày 16/03/2020.](review/20200316.html)
