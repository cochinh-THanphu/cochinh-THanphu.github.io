---
layout: default
title: Home
---

Đây là trang thông tin của cô Chính dành cho quý phụ huynh lớp 1.2.

* Phụ huynh vào mục **[Ôn tập](/Review.html)** để tải bài về cho các em ôn tập.

* Phụ huynh vào mục **[Trò chơi](/review/img/ToMau.01.pdf)** để tải về tranh cho các em tô màu. Đây là hoạt động giúp các em vừa học vừa chơi. Cô Chính sẽ cập nhật thường xuyên các trò chơi để phụ huynh có thể tải về cho các em. Sau kì nghỉ, các em có thể mang tranh lên để trang trí lớp học.

* Thông tin sức khoẻ (Đang cập nhật).



**Thông báo mới.**

* Đã cập nhật bài học cho tuần lễ 16/03/2020 đến 22/03/2020. Xin mời vào phần **[Ôn tập](/Review.html)** để tải về.

> Phụ huynh nếu có ý kiến, ngoài việc gọi vào số điện thoại đã cung cấp, còn có thể gửi email về hòm thư lop12anphuq2@gmail.com.
